Ender 3 Bed Level by sahansudeepa on Thingiverse: https://www.thingiverse.com/thing:4642274

Summary:
Hey guys,This bed levelling design will check the four corners and the middle of the bed by printing squares and the best thing is it prints diagonally from middle square to the corner ones to check the bed adhesion. You can stop printing after the 1st layer because that is enough to check the bed adhesion. But printing all will give the final decision of the flow rate by showing whether the printed lines are overlapped. Link to the video: https://youtu.be/JCdbTgm88hMThanks.Happy Printing.
